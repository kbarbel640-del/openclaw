Run full quality check: format, type-check, and lint.

Run `pnpm check` and report results. If there are errors, fix them automatically where possible using `pnpm lint:fix`, then re-run `pnpm check` to verify.
