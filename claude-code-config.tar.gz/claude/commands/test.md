Run tests for the project.

Run `pnpm test` (all tests in parallel). If specific files were recently changed, consider running `pnpm test:fast` first for quick feedback, then full `pnpm test` to confirm.

Report any failures with file paths and line numbers. Suggest fixes for failing tests.
